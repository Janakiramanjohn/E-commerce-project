import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


public class MyReducer extends Reducer<Text, Text, Text, Text> {
	public void reduce(Text inpK,Iterable<Text> inpV, Context c) throws IOException, InterruptedException{
		double amount=0.0;
		String name=null;
		double max=0;
//		for(Text each: inpV){
//			String[] eachVal = each.toString().split(":");
//			if(eachVal[0].equals("amt")){
//				amount=amount+Double.parseDouble(eachVal[1]);
//			    if(max>amount){
//			    max=amount;
//			    }
//			}
//			else if(eachVal[0].equals("Profession")){
//				name=eachVal[1];
//			}
//			
//		}	
//		c.write(new Text(name), new Text(""+max+""));
	for(Text each:inpV){
			String eachVal[]=each.toString().split(":");
			if(eachVal[0].contains("amt")){
				amount+=Double.parseDouble(eachVal[1]);
			}
		else if(eachVal[0].contains("Profession")){
				name=eachVal[1];
			}
		}
		c.write(new Text("Name is :" +name), new Text("Amount is :" +amount));
		
	}

}